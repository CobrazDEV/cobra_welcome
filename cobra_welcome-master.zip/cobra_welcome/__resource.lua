ui_pag "html/index.html"

client_script "main.lua"

resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

files {
      "html/index.html"
      "html/style.css"
      "html/reset.css"
      "html/listner.js"
}     